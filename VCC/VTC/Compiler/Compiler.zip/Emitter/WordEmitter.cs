﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vasm;
using Vasm.x86;

namespace VTC
{
   public class WordEmitter  : ReferenceSpec
    {
    
       public WordEmitter(MemberSpec ms,int off, ReferenceKind k) : base( k)
       {
      
           Member = ms;
           Offset = off;
       }
       public WordEmitter(MemberSpec ms, int off, ReferenceKind k, RegistersEnum reg)
           : this(ms,off,k)
       {
           Register = reg;
        
       }
       public override bool EmitToRegister(EmitContext ec, RegistersEnum src)
       {
           if (ReferenceType == ReferenceKind.Field)
           {

               ec.EmitComment("Mov Field @" + Signature.ToString() + " " + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = ec.ag.GetHolder(src), SourceRef = ElementReference.New(Signature.ToString()), SourceDisplacement = Offset, SourceIsIndirect = true, Size = 16 });

           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("Mov Var @BP" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = ec.ag.GetHolder(src), SourceReg = EmitContext.BP, SourceDisplacement = Offset, SourceIsIndirect = true, Size = 16 });

           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("Mov Var @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = ec.ag.GetHolder(src), SourceReg = Register, SourceDisplacement = Offset, SourceIsIndirect = true, Size = 16 });
           }
           else
           {
               ec.EmitComment("Mov Parameter @BP " + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = ec.ag.GetHolder(src), SourceReg = EmitContext.BP, Size = 16, SourceDisplacement = Offset, SourceIsIndirect = true });
           }
           return true;
       }
       public override bool EmitFromRegister(EmitContext ec, RegistersEnum src)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("Mov Field @" + Signature.ToString() + " " + Offset);
               ec.EmitInstruction(new Mov() { SourceReg = src, DestinationRef = ElementReference.New(Signature.ToString()), DestinationDisplacement = Offset, DestinationIsIndirect = true, Size = 16 });
           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("Mov Var @BP" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.BP, Size = 16, DestinationDisplacement = Offset, DestinationIsIndirect = true, SourceReg = src });
           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("Mov Var @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = Register, Size = 16, DestinationDisplacement = Offset, DestinationIsIndirect = true, SourceReg = src });
           }
           else
           {
               ec.EmitComment("Mov Parameter @BP " + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.BP, Size = 16, DestinationDisplacement = Offset, DestinationIsIndirect = true, SourceReg = src });
           }
           return true;
       }
       public override bool LoadEffectiveAddress(EmitContext ec, RegistersEnum src)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("AddressOf Field ");

               ec.EmitInstruction(new Lea() { DestinationReg = src, SourceIsIndirect = true, SourceDisplacement = Offset, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });

           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("AddressOf @BP" + Offset);
               ec.EmitInstruction(new Lea() { DestinationReg = src, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });

           }
           else if (ReferenceType == ReferenceKind.Register)
           {

               ec.EmitComment("AddressOf @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Lea() { DestinationReg = src, SourceIsIndirect = true, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
           }
           else
           {
               ec.EmitComment("AddressOf @BP+" + Offset);
               ec.EmitInstruction(new Lea() { DestinationReg = src, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
           }
           return true;
       }
       public override bool ValueOf(EmitContext ec, RegistersEnum src)
       {

           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("ValueOf Field ");
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });
               ec.EmitMovToRegister(src, EmitContext.SI, MemberType.BaseType.SizeInBits, true);
           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("ValueOf @BP" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovToRegister(src, EmitContext.SI, MemberType.BaseType.SizeInBits, true);


           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("ValueOf @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.D, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
               ec.EmitMovToRegister(src, EmitContext.SI, MemberType.BaseType.SizeInBits, true);
           }
           else
           {
               ec.EmitComment("ValueOf @BP+" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovToRegister(src, EmitContext.SI, MemberType.BaseType.SizeInBits, true);
           }
           return true;

       }
       public override bool ValueOfStack(EmitContext ec, RegistersEnum src)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("ValueOf Field ");
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });
               ec.EmitMovFromRegister(EmitContext.SI, src, MemberType.BaseType.SizeInBits, true);

           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("ValueOf Stack @BP" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovFromRegister(EmitContext.SI, src, MemberType.BaseType.SizeInBits, true);

           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("ValueOf Stack @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.D, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
               ec.EmitMovFromRegister(EmitContext.SI, src, MemberType.BaseType.SizeInBits, true);
           }
           else
           {
               ec.EmitComment("ValueOf  Stack @BP+" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovFromRegister(EmitContext.SI, src, MemberType.BaseType.SizeInBits, true);

           }

           return true;
       }
       public override bool ValueOfAccess(EmitContext ec, int off, TypeSpec mem, RegistersEnum src)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("ValueOf Access Field ");
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });
               ec.EmitMovToRegister(src, EmitContext.SI, mem.SizeInBits, true, off);


           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("ValueOf Access @BP" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovToRegister(src, EmitContext.SI, mem.SizeInBits, true, off);

           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("ValueOf Access @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.D, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
               ec.EmitMovToRegister(src, EmitContext.SI, mem.SizeInBits, true, off);
           }
           else
           {
               ec.EmitComment("ValueOf Access @BP+" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovToRegister(src, EmitContext.SI, mem.SizeInBits, true, off);
           }
           return true;
       }
       public override bool ValueOfStackAccess(EmitContext ec, int off, TypeSpec mem, RegistersEnum src)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("ValueOf Access sTACK Field ");
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });
               ec.EmitMovFromRegister(EmitContext.SI, src, mem.SizeInBits, true, off);

           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("ValueOf Stack Access @BP" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovFromRegister(EmitContext.SI, src, mem.SizeInBits, true, off);

           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("ValueOf Stack Access @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.D, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
               ec.EmitMovFromRegister(EmitContext.SI, src, mem.SizeInBits, true, off);
           }
           else
           {
               ec.EmitComment("ValueOf Access Stack @BP+" + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement = Offset });
               ec.EmitMovFromRegister(EmitContext.SI, src, mem.SizeInBits, true, off);
           }
           return true;
       }



       public override bool EmitFromStack(EmitContext ec)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("Pop Field @" + Signature.ToString() + " " + Offset);
               ec.EmitInstruction(new Pop() { DestinationRef = ElementReference.New(Signature.ToString()), DestinationDisplacement = Offset, DestinationIsIndirect = true, Size = memberType.SizeInBits });
           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("Pop Var @BP" +  Offset);
               ec.EmitInstruction(new Pop() { Size = memberType.SizeInBits, DestinationReg = EmitContext.BP, DestinationDisplacement =  Offset, DestinationIsIndirect = true });
           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("Pop Var @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Pop() { Size = memberType.SizeInBits, DestinationReg = Register, DestinationDisplacement = Offset, DestinationIsIndirect = true });
           }
           else
           {
               ec.EmitComment("Pop Parameter @BP " +  Offset);
               ec.EmitInstruction(new Pop() { DestinationReg = EmitContext.BP, Size = memberType.SizeInBits, DestinationDisplacement =  Offset, DestinationIsIndirect = true });
           }
           return true;
       }
       public override bool EmitToStack(EmitContext ec)
       {

           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("Push Field @" + Signature.ToString() + " " + Offset);
               ec.EmitInstruction(new Push() { DestinationRef = ElementReference.New(Signature.ToString()), DestinationDisplacement = Offset, DestinationIsIndirect = true, Size = 16 });
           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("Push Var @BP" +  Offset);
               ec.EmitInstruction(new Push() { DestinationReg = EmitContext.BP, DestinationDisplacement =  Offset, DestinationIsIndirect = true, Size = 16 });
           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("Push Var @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Push() { DestinationReg = Register, DestinationDisplacement = Offset, DestinationIsIndirect = true, Size = 16 });

           }
           else
           {
               ec.EmitComment("Push Parameter @BP " +  Offset);
               ec.EmitInstruction(new Push() { DestinationReg = EmitContext.BP, Size = memberType.SizeInBits, DestinationDisplacement =  Offset, DestinationIsIndirect = true });
           }
           return true;
       }
       public override bool LoadEffectiveAddress(EmitContext ec)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("AddressOf Field ");

               ec.EmitInstruction(new Lea() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, SourceDisplacement = Offset, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });
               ec.EmitPush(EmitContext.SI);
           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {

               ec.EmitComment("AddressOf @BP" +  Offset);
               ec.EmitInstruction(new Lea() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement =  Offset });
               ec.EmitPush(EmitContext.SI);
           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("AddressOf @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Lea() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
               ec.EmitPush(EmitContext.SI);
           }
           else
           {
               ec.EmitComment("AddressOf @BP+" +  Offset);
               ec.EmitInstruction(new Lea() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement =  Offset });
               ec.EmitPush(EmitContext.SI);
           }
           return true;
       }

       public override bool ValueOfAccess(EmitContext ec, int off, TypeSpec mem)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("ValueOf Access Field ");
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });
               ec.EmitPush(EmitContext.SI, mem.SizeInBits, true, off);

           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("ValueOf Access @BP" +  Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement =  Offset });
               ec.EmitPush(EmitContext.SI, mem.SizeInBits, true, off);
           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("ValueOf Access @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
               ec.EmitPush(EmitContext.SI, mem.SizeInBits, true, off);

           }
           else
           {
               ec.EmitComment("ValueOf Access @BP+" +  Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement =  Offset });
          
                   ec.EmitPush(EmitContext.SI, mem.SizeInBits, true, off);
           }
           return true;
       }
       public override bool ValueOfStackAccess(EmitContext ec, int off, TypeSpec mem)
       {
           if (ReferenceType == ReferenceKind.Field)
           {
               ec.EmitComment("ValueOf Access Field ");
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceRef = ElementReference.New(Signature.ToString()) });
               ec.EmitPop(EmitContext.SI, mem.SizeInBits, true, off);

           }
           else if (ReferenceType == ReferenceKind.LocalVariable)
           {
               ec.EmitComment("ValueOf Stack Access @BP" +  Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement =  Offset });
               ec.EmitPop(EmitContext.SI, mem.SizeInBits, true, off);

           }
           else if (ReferenceType == ReferenceKind.Register)
           {
               ec.EmitComment("ValueOf Stack Access @" + Register.ToString() + Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = !memberType.IsArray, Size = 16, SourceReg = Register, SourceDisplacement = Offset });
               ec.EmitPop(EmitContext.SI, mem.SizeInBits, true, off);


           }
           else
           {
               ec.EmitComment("ValueOf Access Stack @BP+" +  Offset);
               ec.EmitInstruction(new Mov() { DestinationReg = EmitContext.SI, SourceIsIndirect = true, Size = 16, SourceReg = EmitContext.BP, SourceDisplacement =  Offset });
           
                   ec.EmitPop(EmitContext.SI, mem.SizeInBits, true, off);
           }
           return true;
       }
    }
}
