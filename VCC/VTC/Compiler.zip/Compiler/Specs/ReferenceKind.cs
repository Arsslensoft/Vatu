using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vasm;
using Vasm.x86;

namespace VTC
{
	 public enum ReferenceKind
    {
        Field,
        LocalVariable,
        Parameter,
        EnumValue,
        Type,
        Member,
        Method,
        Operator,
         Register
    }
  
	
	
}