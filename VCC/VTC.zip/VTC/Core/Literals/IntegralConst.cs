﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VTC.Core
{
    public class IntegralConst : Literal
    {

        public IntegralConst(string val,bool num=false)
            : base(val, num)
        {

        }

    }
}
