using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vasm;
using Vasm.x86;

namespace VTC
{
	 public interface IMember
    {
        TypeSpec MemberType { get; }
    }

	
	
}