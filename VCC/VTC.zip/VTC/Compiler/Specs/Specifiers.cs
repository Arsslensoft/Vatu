using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vasm;
using Vasm.x86;

namespace VTC
{
	 public enum Specifiers
    {
         NoSpec=0,
         Entry = 1,
         Isolated = 2,
         Variadic = 4
    }
    
	
	
}