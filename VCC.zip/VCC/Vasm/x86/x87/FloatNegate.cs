﻿namespace Vasm.x86.x87
{
    [Vasm.OpCode("fchs")]
    public class FloatNegate : Instruction
    {
    }
}