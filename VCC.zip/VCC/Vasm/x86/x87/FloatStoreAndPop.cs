﻿namespace Vasm.x86.x87
{
    [Vasm.OpCode("fstp")]
    public class FloatStoreAndPop : InstructionWithDestinationAndSize
    {
    }
}