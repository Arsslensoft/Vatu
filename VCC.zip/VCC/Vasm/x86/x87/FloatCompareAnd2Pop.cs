﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vasm.x86.X86.x87
{
    [Vasm.OpCode("fcompp")]
    public class FloatCompareAnd2Pop : Instruction
    {
    }
}
