﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vasm.x86.x87
{
    [Vasm.OpCode("fabs")]
    public class FloatABS : Instruction
    {
    }
}
