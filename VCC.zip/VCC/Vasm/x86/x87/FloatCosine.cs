﻿namespace Vasm.x86.x87
{
    [Vasm.OpCode("fcos")]
    public class FloatCosine : Instruction
    {
    }
}
