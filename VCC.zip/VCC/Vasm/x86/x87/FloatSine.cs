﻿namespace Vasm.x86.x87
{
    [Vasm.OpCode("fsin")]
    public class FloatSine : Instruction
    {
    }
}
