﻿namespace Vasm.x86.x87
{
    [Vasm.OpCode("fsqrt")]
    public class FloatSqrt : Instruction
    {
    }
}