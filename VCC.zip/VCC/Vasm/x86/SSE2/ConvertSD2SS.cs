﻿namespace Vasm.x86.SSE
{
    [Vasm.OpCode("CVTSD2SS")]
	public class ConvertSD2SS : InstructionWithDestinationAndSource
	{
	}
}