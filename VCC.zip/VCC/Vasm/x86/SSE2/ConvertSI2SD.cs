﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("cvtsi2sd")]
	public class ConvertSI2SD : InstructionWithDestinationAndSource
	{
	}
}