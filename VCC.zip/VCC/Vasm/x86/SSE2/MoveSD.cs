﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("movsd")]
	public class MoveSD : InstructionWithDestinationAndSource
	{
	}
}