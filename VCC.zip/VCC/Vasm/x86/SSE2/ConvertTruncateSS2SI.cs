﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("CVTTSS2SI")]
	public class ConvertSS2SIAndTruncate : InstructionWithDestinationAndSource
	{
	}
}