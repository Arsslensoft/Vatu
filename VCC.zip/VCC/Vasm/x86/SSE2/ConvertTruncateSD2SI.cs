﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("CVTTSD2SI")]
	public class ConvertSD2SIAndTruncate : InstructionWithDestinationAndSource
	{
	}
}