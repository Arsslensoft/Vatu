﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("cvtss2sd")]
	public class ConvertSS2SD : InstructionWithDestinationAndSource
	{
	}
}