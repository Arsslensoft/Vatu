﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("CVTSD2SI")]
	public class ConvertSD2SI : InstructionWithDestinationAndSource
	{
	}
}