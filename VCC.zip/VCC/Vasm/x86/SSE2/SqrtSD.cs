﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("sqrtsd")]
	public class SqrtScalardDouble : InstructionWithDestinationAndSource
	{
	}
}