﻿namespace Vasm.x86.SSE
{
	[Vasm.OpCode("MOVDDUP")]
	public class MoveDoubleAndDupplicate : InstructionWithDestinationAndSource
	{
	}
}