﻿using System;
using System.Linq;

namespace Vasm.x86
{
    [Vasm.OpCode("hlt")]
    public class Halt : Instruction
    {
    }
}