﻿using System;
using System.Linq;

namespace Vasm.x86 {
    [Vasm.OpCode("cmpxchg")]
	public class CmpXchg: InstructionWithDestinationAndSourceAndSize {
	}
}