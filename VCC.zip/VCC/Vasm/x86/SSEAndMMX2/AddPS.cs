﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vasm.x86.X86.SSE
{
    [Vasm.OpCode("addps")]
    public class AddPS : InstructionWithDestinationAndSource
    {
    }
}
