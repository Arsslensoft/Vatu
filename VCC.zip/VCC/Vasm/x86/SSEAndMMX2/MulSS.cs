﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vasm.x86.SSE
{
    [Vasm.OpCode("mulss")]
    public class MulSS : InstructionWithDestinationAndSource
    {
    }
}
