﻿namespace Vasm.x86
{
	[Vasm.OpCode("shrd")]
	public class ShiftRightDouble : InstructionWithDestinationAndSourceAndArgument
	{
	}
}