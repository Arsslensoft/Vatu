﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vasm.x86
{
    [Vasm.OpCode("stosd")]
    public class StoreSD : Instruction
    {
#warning todo: merge with stosb and stosw
    }
}
