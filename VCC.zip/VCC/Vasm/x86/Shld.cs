﻿namespace Vasm.x86
{
	[Vasm.OpCode("shld")]
	public class ShiftLeftDouble : InstructionWithDestinationAndSourceAndArgument
	{
	}
}